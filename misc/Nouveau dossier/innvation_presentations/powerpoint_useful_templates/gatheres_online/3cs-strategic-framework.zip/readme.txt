

SLIDEHUNTER.COM

-----------------------------------------------------------------------------

This is a free template provided by SlideHunter.

You can download more free PowerPoint backgrounds from slidehunter.com

Follow us on Twitter @slideh

Subscribe to our mailing list at http://slidehunter.com/

-----------------------------------------------------------------------------

Download business characters and vectors for your PowerPoint presentations